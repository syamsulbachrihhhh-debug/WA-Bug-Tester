package com.jaccksallas.wabugtester

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var result: TextView
    private lateinit var history: TextView
    private val historyItems = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "WA Bug Tester"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF14532D.toInt())
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Alat uji teks lokal. Tidak mengirim pesan dan tidak mengubah WhatsApp."
            textSize = 14f
            setPadding(0, 8, 0, 18)
        }
        root.addView(subtitle)

        input = EditText(this).apply {
            hint = "Tulis atau tempel teks untuk diuji..."
            minLines = 4
            gravity = Gravity.TOP
            setTextSize(16f)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(input, matchWidth())

        addButton(root, "Uji teks") { runTextTest() }
        addButton(root, "Salin teks uji") { copyText() }
        addButton(root, "Bagikan ke WhatsApp") { shareToWhatsApp() }

        result = TextView(this).apply {
            text = "Hasil pengujian akan muncul di sini."
            textSize = 15f
            setTextColor(0xFF1F2937.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(result, matchWidth())

        val historyTitle = TextView(this).apply {
            text = "Riwayat pengujian"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 22, 0, 8)
        }
        root.addView(historyTitle)

        history = TextView(this).apply {
            text = "Belum ada pengujian."
            textSize = 14f
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(history, matchWidth())

        addButton(root, "Hapus riwayat") {
            historyItems.clear()
            history.text = "Belum ada pengujian."
            Toast.makeText(this, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
        }
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(button, matchWidth())
    }

    private fun runTextTest() {
        val text = input.text.toString()
        val lines = text.lines().size
        val chars = text.length
        val codePoints = text.codePointCount(0, text.length)
        val bytes = text.toByteArray(Charsets.UTF_8).size
        val specialCount = text.count { !it.isLetterOrDigit() && !it.isWhitespace() }
        val emojiCount = text.codePoints().toArray().count {
            Character.getType(it) == Character.OTHER_SYMBOL.toInt()
        }

        val report = buildString {
            appendLine("HASIL UJI TEKS")
            appendLine("Karakter: $chars")
            appendLine("Code point Unicode: $codePoints")
            appendLine("Ukuran UTF-8: $bytes byte")
            appendLine("Jumlah baris: $lines")
            appendLine("Simbol/tanda baca: $specialCount")
            appendLine("Simbol bergambar terdeteksi: $emojiCount")
            appendLine()
            append("Status: teks berhasil dianalisis secara lokal.")
        }
        result.text = report
        val stamp = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        historyItems.add(0, "$stamp — $chars karakter, $bytes byte")
        history.text = historyItems.take(20).joinToString("\n")
    }

    private fun copyText() {
        val text = input.text.toString()
        if (text.isEmpty()) {
            Toast.makeText(this, "Masukkan teks terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Teks uji", text))
        Toast.makeText(this, "Teks disalin", Toast.LENGTH_SHORT).show()
    }

    private fun shareToWhatsApp() {
        val text = input.text.toString()
        if (text.isEmpty()) {
            Toast.makeText(this, "Masukkan teks terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            setPackage("com.whatsapp")
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "WhatsApp tidak ditemukan. Teks tetap bisa disalin.", Toast.LENGTH_LONG).show()
        }
    }
}
